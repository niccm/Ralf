# RalfBites
RalfBites is a Android application that is similar to Doordash and UberEats
