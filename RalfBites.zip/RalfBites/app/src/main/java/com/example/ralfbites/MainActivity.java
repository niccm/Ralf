package com.example.ralfbites;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

/**
 * @author Nicolas Mederos
 * @since 18 April 2023
 * Starting the project
 */

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}